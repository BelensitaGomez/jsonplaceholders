export default function Blog(){
    return (
        <>
            <h1>Blog</h1>
            <p>Estas en blog</p>
        </>
    );
}