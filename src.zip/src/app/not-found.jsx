import "@/app/not-found.css"
export default function NoFound(){
    return (
        <div className="centrar">
        <h1>ERROR 404</h1>
        <p>Página no encontrada</p>
        </div>
    );
}