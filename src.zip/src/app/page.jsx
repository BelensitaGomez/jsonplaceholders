export default function Inicio(){
    return(
        <h1>Hola, esto es next...</h1>
    );
}