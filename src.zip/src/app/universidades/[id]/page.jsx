export default function Universidad({params}){
    return(
        <>
        <h1>Estas  en universidad</h1>
        <p>{params.id}</p>
        </>
    );
}